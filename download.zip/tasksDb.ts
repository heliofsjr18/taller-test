export const tasks = [
    {
        id: 1,
        title: 'any title 1',
        completed: false
    },
    {
        id: 2,
        title: 'any title 2',
         completed: true
    },
    {
        id: 2,
        title: 'any title 2',
         completed: true
    },
    {
        id: 2,
        title: 'any title 2',
         completed: true
    },
    {
        id: 2,
        title: 'any title 2',
         completed: false
    }
]